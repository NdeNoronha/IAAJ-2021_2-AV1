﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework;

namespace EstudoRápidoIAProva
{
    class Background : StaticSprite
    {
        public Background(Texture2D myTexture, Rectangle myRectangle)
        {
            texture = myTexture;
            rectangle = myRectangle;
        }
    }
}
