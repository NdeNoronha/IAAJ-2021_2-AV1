﻿using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;

namespace EstudoRápidoIAProva
{
    /// <summary>
    /// This is the main type for your game
    /// </summary>
    public class Game1 : Microsoft.Xna.Framework.Game
    {
        GraphicsDeviceManager graphics;
        SpriteBatch spriteBatch;

        Texture2D playerText;
        Texture2D floorText;
        Texture2D backgroundText;
        Rectangle backgroundRect;
        Rectangle flooRect, floorBound;
        Rectangle playeRect, playerBound;
        Player player;
        Background background;
        Floor floor;
        public Game1()
        {
            graphics = new GraphicsDeviceManager(this);
            Content.RootDirectory = "Content";

            graphics.PreferredBackBufferWidth = 1046;
            graphics.PreferredBackBufferHeight = 610;
        }

        /// <summary>
        /// Allows the game to perform any initialization it needs to before starting to run.
        /// This is where it can query for any required services and load any non-graphic
        /// related content.  Calling base.Initialize will enumerate through any components
        /// and initialize them as well.
        /// </summary>
        protected override void Initialize()
        { 
            // TODO: Add your initialization logic here
            playerText = Content.Load<Texture2D>(@"Images\player");
            backgroundText = Content.Load<Texture2D>(@"Images\Background");
            floorText = Content.Load<Texture2D>(@"Images\floor");

            flooRect = new Rectangle(0, 520, 1046, 22);
            playeRect = new Rectangle(900, 485, playerText.Width/2, playerText.Height/3);
            backgroundRect = new Rectangle(0, 0, backgroundText.Width, backgroundText.Height);

            this.player = new Player(playerText, playeRect, 50, 1);
            this.background = new Background(backgroundText, backgroundRect);

            floor = new Floor(floorText, flooRect);
            base.Initialize();
        }

        /// <summary>
        /// LoadContent will be called once per game and is the place to load
        /// all of your content.
        /// </summary>
        protected override void LoadContent()
        {
            // Create a new SpriteBatch, which can be used to draw textures.
            spriteBatch = new SpriteBatch(GraphicsDevice);
            // TODO: use this.Content to load your game content here
        }

        /// <summary>
        /// UnloadContent will be called once per game and is the place to unload
        /// all content.
        /// </summary>
        protected override void UnloadContent()
        {
            // TODO: Unload any non ContentManager content here
        }

        /// <summary>
        /// Allows the game to run logic such as updating the world,
        /// checking for collisions, gathering input, and playing audio.
        /// </summary>
        /// <param name="gameTime">Provides a snapshot of timing values.</param>
        protected override void Update(GameTime gameTime)
        {
            playerBound = playeRect;
            //Console.WriteLine(flooRect.X);
            //Console.WriteLine(flooRect.Y);
            //Console.WriteLine(flooRect.Width);
            //Console.WriteLine(flooRect.Height);
            // Allows the game to exit
            if (GamePad.GetState(PlayerIndex.One).Buttons.Back == ButtonState.Pressed)
                this.Exit();
            this.player.Update(gameTime);

            if (playerBound.Intersects(flooRect))
            // TODO: Add your update logic here
            base.Update(gameTime);
        }

        /// <summary>
        /// This is called when the game should draw itself.
        /// </summary>
        /// <param name="gameTime">Provides a snapshot of timing values.</param>
        protected override void Draw(GameTime gameTime)
        {
            GraphicsDevice.Clear(Color.CornflowerBlue);

            // TODO: Add your drawing code here
            spriteBatch.Begin();
            background.Draw(spriteBatch);
            floor.Draw(spriteBatch);
            player.Draw(spriteBatch);
            spriteBatch.End();
            base.Draw(gameTime);
        }
    }
}
