﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework;

namespace EstudoRápidoIAProva
{
    public class Floor
    {
        Texture2D texture;
        Rectangle rectangle;

        public Floor(Texture2D myTexture, Rectangle myRectangle)
        {
            texture = myTexture;
            rectangle = myRectangle;
        }

        public void Draw(SpriteBatch spriteBatch)
        {
            spriteBatch.Draw(texture, rectangle, Color.White);
        }
    }
}
