﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework;

namespace EstudoRápidoIAProva
{
    public class Sprite
    {
        Texture2D myTexture;
        Rectangle myRect;
        Vector2 origin, position;

        int currentFrame, frameHeight, frameWidth, maxFrame;
        float timer, interval;
        public SpriteEffects effects;

        public Sprite(Texture2D myTexture, Vector2 position, int frameHeight, int frameWidth, float interval, int maxFrame)
        {
            this.myTexture = myTexture;
            this.position = position;
            this.frameHeight = frameHeight;
            this.frameWidth = frameWidth;
            this.interval = interval;
            this.maxFrame = maxFrame;
            this.effects = SpriteEffects.None;
        }

        public void Update(GameTime gameTime)
        {
            this.myRect = new Rectangle(currentFrame * frameWidth, 0, frameWidth, frameHeight);
            origin = new Vector2(this.myRect.Width/2, this.myRect.Height/2);
        }

        public void Animation(GameTime gameTime)
        {
            timer += (float)gameTime.ElapsedGameTime.Milliseconds / 2;
            if (timer > interval)
            {
                currentFrame++;
                timer = 0;
                if (currentFrame > this.maxFrame)
                    currentFrame = 0;
            }
        }

        public void Draw(SpriteBatch spriteBatch)
        {
            spriteBatch.Draw(this.myTexture, this.position,this.myRect, Color.White, 0f, origin, 1.0f, this.effects, 0);
        }
    }
}
