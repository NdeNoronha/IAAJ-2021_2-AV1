﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Input;

using KopiLua;
using NLua;

namespace EstudoRápidoIAProva
{
    enum ANIMATION
    {
        WALKINGLEFT, WALKINGRIGHT, DOWN, JUMP
    };
    public class Player
    {
        Texture2D myTexture;
        public Rectangle myRect;
        public Vector2 origin, position, velocity;
        ANIMATION animation;
        int animationIndex;
        public bool onFloor;

        int currentFrame, frameHeight, frameWidth, maxFrame, lookLeft;
        public float timer, interval, speed, jump, t;
        SpriteEffects effects;

        NLua.Lua lua;

        public Player(Texture2D myTexture, Rectangle secondRect, float interval, int maxFrame)
        {
            this.myTexture = myTexture;
            this.position = new Vector2(secondRect.X, secondRect.Y);
            this.frameHeight = secondRect.Height;
            this.frameWidth = secondRect.Width;
            this.interval = interval;
            this.maxFrame = maxFrame;
           // this.speed = 3;
           // this.hasJumped = false;
            this.effects = SpriteEffects.None;

            this.lua = new NLua.Lua();

            this.lua.RegisterFunction("GoRight", this, this.GetType().GetMethod("GoRight"));
            this.lua.RegisterFunction("GoLeft", this, this.GetType().GetMethod("GoLeft"));
            try
            {
                ScriptLua("Start");
            }
            catch (Exception e)
            {
                Console.WriteLine("StartError: " + e.Message);
            }
        }


        public void Update(GameTime gameTime)
        {
            try
            {
                ScriptLua("Update");
            }
            catch (Exception e)
            {
                Console.WriteLine("UpdateError: " + e.Message);
            }

            if (position.X < 0)
            {
                velocity.X = 0;
            }

            Console.WriteLine(jump);
            position += velocity;
            
            this.myRect = new Rectangle(currentFrame * frameWidth, animationIndex * frameHeight, frameWidth, frameHeight);
            origin = new Vector2(this.myRect.Width / 2, this.myRect.Height / 2);
            AnimationTransition(gameTime);
            Controls();
        }

        public void GoRight()
        {
            this.velocity.X = 3;
            animation = ANIMATION.WALKINGRIGHT;
        }

        public void GoLeft()
        {
            this.velocity.X = -3;
            animation = ANIMATION.WALKINGLEFT;
        }

        private void Controls()
        {
            if (Keyboard.GetState().IsKeyDown(Keys.Right))
            {
                this.velocity.X = 3;
                animation = ANIMATION.WALKINGRIGHT;
            }
            else
            {
                this.velocity.X = 0;
            }
            if (Keyboard.GetState().IsKeyDown(Keys.Left))
            {
                this.velocity.X = -3;
                animation = ANIMATION.WALKINGLEFT;
            }

            if (Keyboard.GetState().IsKeyDown(Keys.Down))
            {
                speed = 0;
                animation = ANIMATION.DOWN;
            }

            if (Keyboard.GetState().IsKeyDown(Keys.Space))
            {
                onFloor = false;
                jump = 1;
                position.Y -= 10f;
                velocity.Y = -5f; 
                currentFrame = 0;
                animation = ANIMATION.JUMP;
            }

            if (onFloor == true)
            {
                velocity.Y = 0;
            }
            if (Keyboard.GetState().IsKeyUp(Keys.Left) && Keyboard.GetState().IsKeyUp(Keys.Right))
            {
                currentFrame = 0;
            }
            if (Keyboard.GetState().IsKeyUp(Keys.Down) && Keyboard.GetState().IsKeyUp(Keys.Space))
            {
                animationIndex = 0;
            }
            //if (onFloor == false || jump == 1)
            //{
            //    float i = 10;
            //    velocity.Y += 0.15f * i;
            //}
        }

        public void Animation(GameTime gameTime)
        {
            timer += (float)gameTime.ElapsedGameTime.Milliseconds / 2;
            if (timer > interval)
            {
                currentFrame++;
                timer = 0;
                if (currentFrame > this.maxFrame)
                    currentFrame = 0;
            }
        }

        public void AnimationTransition(GameTime gameTime)
        {
            switch (animation)
            {
                case ANIMATION.WALKINGRIGHT:
                    Animation(gameTime);
                    this.lookLeft = 0;
                    if (lookLeft == 0)
                        this.effects = SpriteEffects.None;
                break;
                case ANIMATION.WALKINGLEFT:
                    this.lookLeft = 1;
                    Animation(gameTime);
                    if(lookLeft == 1)
                        this.effects = SpriteEffects.FlipHorizontally;
                break;
                case ANIMATION.DOWN:
                animationIndex = 1;
                break;
                case ANIMATION.JUMP:
                animationIndex = 2;
                break;
            }
        }

        private void ScriptLua(string function)
        {
            this.lua.DoFile(@"GameObjectLua.txt");
            ((LuaFunction)this.lua[function]).Call();
        }

        public void Draw(SpriteBatch spriteBatch)
        {
            spriteBatch.Draw(this.myTexture, this.position, this.myRect, Color.White, 0f, origin, 1.0f, this.effects, 0);
        }
    }
}
